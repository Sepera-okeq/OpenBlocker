package gloomyfolken.hooklib.asm;

public enum HookPriority {

    HIGHEST, // Вызывается первым
    HIGH,
    NORMAL,
    LOW,
    LOWEST // Вызывается последним

}
